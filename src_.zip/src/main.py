from views.menus import Menus


def main() -> None:

    menu = Menus()
    menu.run()


if __name__ == "__main__":
    main()
